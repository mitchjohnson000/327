/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   stringfileparser.h
 * Author: mdj
 *
 * Created on March 27, 2017, 7:57 PM
 */
#include "dice.h"
#ifndef STRINGFILEPARSER_H
#define STRINGFILEPARSER_H

using namespace std;

void parse_monsters(const char *path);



#endif /* STRINGFILEPARSER_H */

