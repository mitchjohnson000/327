/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Test.cpp
 * Author: mdj
 *
 * Created on March 20, 2017, 9:06 PM
 */

#include <iostream>
#include "test_header.h"


using namespace std;

void doNothing(){
    cout << "WOEJFASJODFOAHSODFHAHSDFHAOSFDH" << endl;
}



