/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   test_header.h
 * Author: mdj
 *
 * Created on March 20, 2017, 9:07 PM
 */

#ifndef TEST_HEADER_H
#define TEST_HEADER_H

#ifdef __cplusplus
extern "C" {
#endif

    void doNothing();


#ifdef __cplusplus
}
#endif

#endif /* TEST_HEADER_H */

